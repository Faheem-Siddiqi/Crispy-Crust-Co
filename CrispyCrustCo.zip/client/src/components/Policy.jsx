import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const Policy = () => {
  return (
    <>
      <Container style={{ marginTop: "50px" }}>
      <h3 style={{color:"#FF1493"}} >Terms and Policy</h3>
        <Row>
          <Col md={10}>
            <h6>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
            <h6 className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
            <h6 className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
            <h6>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
            <h6 className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
            <h6>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum,
              praesentium?
            </h6>
            <p className="textP">
              Lorem ipsum dolor sit amet consectetur adipisicing elit. In magnam
              officia nemo unde neque iusto minima reiciendis vitae nam deserunt
              qui nulla rem voluptas, non velit earum, corrupti delectus sint!
              Quibusdam quam aliquam eveniet molestias fuga assumenda culpa at,
              temporibus tempore perspiciatis repellat architecto iste
              aspernatur repellendus quaerat reprehenderit libero excepturi iure
              nisi! Ipsum unde voluptatibus repellendus provident esse aliquam
              labore, inventore ex autem nobis sunt. Cupiditate unde impedit
              ullam blanditiis quos molestias molestiae modi iusto dignissimos,
              sed architecto? Officiis, esse perferendis. Dolor dolores
              voluptates quos, officia voluptatibus nesciunt voluptatum
              voluptatem ipsa, minus magni, quisquam illum sit quis itaque quas.
            </p>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default Policy;
